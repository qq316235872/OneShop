-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : corethink
-- 
-- Part : #1
-- Date : 2015-07-28 09:53:57
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ct_addon`
-- -----------------------------
DROP TABLE IF EXISTS `ct_addon`;
CREATE TABLE `ct_addon` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '插件名或标识',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text NOT NULL COMMENT '插件描述',
  `config` text COMMENT '配置',
  `author` varchar(32) NOT NULL DEFAULT '' COMMENT '作者',
  `version` varchar(8) NOT NULL DEFAULT '' COMMENT '版本号',
  `adminlist` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '插件类型',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `ct_addon`
-- -----------------------------
INSERT INTO `ct_addon` VALUES ('1', 'ReturnTop', '返回顶部', '返回顶部', '{\"status\":\"1\",\"theme\":\"rocket\",\"customer\":\"\",\"case\":\"\",\"qq\":\"\",\"weibo\":\"\"}', 'CoreThink', '1.0', '0', '0', '1407681961', '1408602081', '0', '1');
INSERT INTO `ct_addon` VALUES ('2', 'Email', '邮件插件', '实现系统发邮件功能', '{\"status\":\"1\",\"MAIL_SMTP_TYPE\":\"1\",\"MAIL_SMTP_SECURE\":\"0\",\"MAIL_SMTP_PORT\":\"25\",\"MAIL_SMTP_HOST\":\"smtp.qq.com\",\"MAIL_SMTP_USER\":\"\",\"MAIL_SMTP_PASS\":\"\",\"default\":\"[MAILBODY]\"}', 'CoreThink', '1.0', '0', '0', '1428732454', '1428732454', '0', '1');
INSERT INTO `ct_addon` VALUES ('3', 'SyncLogin', '第三方账号登陆', '第三方账号登陆', '{\"type\":[\"Weixin\",\"Qq\",\"Sina\",\"Renren\"],\"meta\":\"\",\"WeixinKEY\":\"\",\"WeixinSecret\":\"\",\"QqKEY\":\"\",\"QqSecret\":\"\",\"SinaKEY\":\"\",\"SinaSecret\":\"\",\"RenrenKEY\":\"\",\"RenrenSecret\":\"\"}', 'CoreThink', '1.0', '1', '0', '1428250248', '1428250248', '0', '1');
INSERT INTO `ct_addon` VALUES ('4', 'AdFloat', '图片漂浮广告', '图片漂浮广告', '{\"status\":\"0\",\"url\":\"http:\\/\\/www.corethink.cn\",\"image\":\"\",\"width\":\"100\",\"height\":\"100\",\"speed\":\"10\",\"target\":\"1\"}', 'CoreThink', '1.0', '0', '0', '1408602081', '1408602081', '0', '1');

-- -----------------------------
-- Table structure for `ct_addon_hook`
-- -----------------------------
DROP TABLE IF EXISTS `ct_addon_hook`;
CREATE TABLE `ct_addon_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '钩子ID',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `addons` varchar(255) NOT NULL COMMENT '钩子挂载的插件 ''，''分割',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `ct_addon_hook`
-- -----------------------------
INSERT INTO `ct_addon_hook` VALUES ('1', 'PageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', 'SyncLogin', '1', '1407681961', '1407681961', '1');
INSERT INTO `ct_addon_hook` VALUES ('2', 'PageFooter', '页面footer钩子，一般用于加载插件CSS文件和代码', 'ReturnTop,AdFloat', '1', '1407681961', '1407681961', '1');
INSERT INTO `ct_addon_hook` VALUES ('3', 'SyncLogin', '第三方登陆', 'SyncLogin', '1', '1407681961', '1407681961', '1');

-- -----------------------------
-- Table structure for `ct_addon_sync_login`
-- -----------------------------
DROP TABLE IF EXISTS `ct_addon_sync_login`;
CREATE TABLE `ct_addon_sync_login` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int(11) unsigned NOT NULL COMMENT '用户ID',
  `type` varchar(15) NOT NULL DEFAULT '' COMMENT '类别',
  `openid` varchar(64) NOT NULL DEFAULT '' COMMENT 'OpenID',
  `access_token` varchar(64) NOT NULL DEFAULT '' COMMENT 'AccessToken',
  `refresh_token` varchar(64) NOT NULL DEFAULT '' COMMENT 'RefreshToken',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='第三方登陆插件表';


-- -----------------------------
-- Table structure for `ct_category`
-- -----------------------------
DROP TABLE IF EXISTS `ct_category`;
CREATE TABLE `ct_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '父分类ID',
  `group` tinyint(4) NOT NULL DEFAULT '0' COMMENT '分组',
  `doc_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '分类模型',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '分类名称',
  `url` varchar(128) NOT NULL COMMENT '链接地址',
  `content` text NOT NULL COMMENT '内容',
  `index_template` varchar(32) NOT NULL DEFAULT '' COMMENT '列表封面模版',
  `detail_template` varchar(32) NOT NULL DEFAULT '' COMMENT '详情页模版',
  `post_auth` tinyint(4) NOT NULL DEFAULT '0' COMMENT '投稿权限',
  `icon` varchar(32) NOT NULL DEFAULT '' COMMENT '缩略图',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='栏目分类表';

-- -----------------------------
-- Records of `ct_category`
-- -----------------------------
INSERT INTO `ct_category` VALUES ('1', '0', '1', '3', '文章', '', '', 'index_default', 'detail_default', '1', 'fa fa-send-o', '1431926468', '1435895071', '1', '1');
INSERT INTO `ct_category` VALUES ('9', '0', '1', '1', '会员', 'User/index', '', '', '', '0', 'fa fa-users', '1435894071', '1435895080', '9', '0');
INSERT INTO `ct_category` VALUES ('10', '0', '1', '1', '标签', 'Tag/index', '', '', '', '0', 'fa fa-tags', '1435896603', '1435896603', '11', '0');
INSERT INTO `ct_category` VALUES ('15', '0', '3', '1', '底部导航', '', '', '', '', '1', 'fa fa-navicon', '1435896768', '1435896768', '1', '1');
INSERT INTO `ct_category` VALUES ('16', '15', '3', '1', '关于', '', '', '', '', '0', '', '1435896839', '1435896839', '0', '1');
INSERT INTO `ct_category` VALUES ('17', '16', '3', '2', '关于我们', '', '', '', '', '0', '', '1435896882', '1435921242', '0', '1');
INSERT INTO `ct_category` VALUES ('18', '16', '3', '2', '商务合作', '', '', '', '', '0', '', '1435896882', '1435896882', '0', '1');
INSERT INTO `ct_category` VALUES ('19', '16', '3', '2', '友情链接', '', '', '', '', '0', '', '1435896882', '1435896882', '0', '1');
INSERT INTO `ct_category` VALUES ('20', '16', '3', '2', '加入我们', '', '', '', '', '0', '', '1435896882', '1435896882', '0', '1');
INSERT INTO `ct_category` VALUES ('21', '15', '3', '1', '帮助', '', '', '', '', '0', '', '1435922411', '1435922411', '0', '1');
INSERT INTO `ct_category` VALUES ('22', '21', '3', '2', '用户协议', '', '', '', '', '0', '', '1435922579', '1435922579', '0', '1');
INSERT INTO `ct_category` VALUES ('23', '21', '3', '2', ' 常见问题', '', '', '', '', '0', '', '1435922602', '1435922602', '0', '1');
INSERT INTO `ct_category` VALUES ('24', '21', '3', '2', '意见反馈', '', '', '', '', '0', '', '1435922628', '1435922628', '0', '1');
INSERT INTO `ct_category` VALUES ('25', '15', '3', '1', '服务产品', '', '', '', '', '0', '', '1435922794', '1435922794', '0', '1');
INSERT INTO `ct_category` VALUES ('26', '25', '3', '1', 'CoreThink框架', '', '', '', '', '0', '', '1435922823', '1435922823', '0', '1');
INSERT INTO `ct_category` VALUES ('27', '25', '3', '1', '微＋微信平台', '', '', '', '', '0', '', '1435922866', '1435923215', '0', '1');
INSERT INTO `ct_category` VALUES ('28', '25', '3', '1', '游戏约', 'http://youxiyue.cn', '', '', '', '0', '', '1435922893', '1435922893', '0', '1');
INSERT INTO `ct_category` VALUES ('29', '15', '3', '1', '手册', '', '', '', '', '0', '', '1435922918', '1435922918', '0', '1');
INSERT INTO `ct_category` VALUES ('30', '29', '3', '1', 'CoreThink手册', '', '', '', '', '0', '', '1435922944', '1435923226', '0', '1');
INSERT INTO `ct_category` VALUES ('31', '29', '3', '1', 'ThinkPHP3.2手册', 'http://document.thinkphp.cn/manual_3_2.html', '', '', '', '0', '', '1435923030', '1435923030', '0', '1');

-- -----------------------------
-- Table structure for `ct_document`
-- -----------------------------
DROP TABLE IF EXISTS `ct_document`;
CREATE TABLE `ct_document` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `cid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `doc_type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文档类型ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布者ID',
  `title` char(127) NOT NULL DEFAULT '' COMMENT '标题',
  `view` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '阅读量',
  `comment` int(11) NOT NULL DEFAULT '0' COMMENT '评论数',
  `good` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '赞数',
  `bad` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '踩数',
  `mark` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '收藏',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档类型基础表';


-- -----------------------------
-- Table structure for `ct_document_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `ct_document_attribute`;
CREATE TABLE `ct_document_attribute` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段标题',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `tip` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `options` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `doc_type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '文档模型',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='文档属性字段表';

-- -----------------------------
-- Records of `ct_document_attribute`
-- -----------------------------
INSERT INTO `ct_document_attribute` VALUES ('1', 'cid', '分类', 'int(11) unsigned NOT NULL ', 'select', '0', '所属分类', '1', '', '0', '1383891233', '1384508336', '1');
INSERT INTO `ct_document_attribute` VALUES ('2', 'uid', '用户ID', 'int(11) unsigned NOT NULL ', 'num', '0', '用户ID', '0', '', '0', '1383891233', '1384508336', '1');
INSERT INTO `ct_document_attribute` VALUES ('3', 'title', '标题', 'char(127) NOT NULL ', 'text', '', '文档标题', '1', '', '0', '1383891233', '1383894778', '1');
INSERT INTO `ct_document_attribute` VALUES ('4', 'view', '阅读量', 'varchar(255) NOT NULL', 'num', '0', '标签', '0', '', '0', '1413303715', '1413303715', '1');
INSERT INTO `ct_document_attribute` VALUES ('5', 'comment', '评论数', 'int(11) unsigned NOT NULL ', 'num', '0', '评论数', '0', '', '0', '1383891233', '1383894927', '1');
INSERT INTO `ct_document_attribute` VALUES ('6', 'good', '赞数', 'int(11) unsigned NOT NULL ', 'num', '0', '赞数', '0', '', '0', '1383891233', '1384147827', '1');
INSERT INTO `ct_document_attribute` VALUES ('7', 'bad', '踩数', 'int(11) unsigned NOT NULL ', 'num', '0', '踩数', '0', '', '0', '1407646362', '1407646362', '1');
INSERT INTO `ct_document_attribute` VALUES ('8', 'ctime', '创建时间', 'int(11) unsigned NOT NULL ', 'time', '0', '创建时间', '1', '', '0', '1383891233', '1383895903', '1');
INSERT INTO `ct_document_attribute` VALUES ('9', 'utime', '更新时间', 'int(11) unsigned NOT NULL ', 'time', '0', '更新时间', '0', '', '0', '1383891233', '1384508277', '1');
INSERT INTO `ct_document_attribute` VALUES ('10', 'sort', '排序', 'int(11) unsigned NOT NULL ', 'num', '0', '用于显示的顺序', '1', '', '0', '1383891233', '1383895757', '1');
INSERT INTO `ct_document_attribute` VALUES ('11', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '1', '', '0', '-1:删除\r\n0:禁用\r\n1:正常', '0', '1383891233', '1384508496', '1');
INSERT INTO `ct_document_attribute` VALUES ('12', 'abstract', '简介', 'varchar(255) NOT NULL', 'textarea', '', '文档简介', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `ct_document_attribute` VALUES ('13', 'content', '正文内容', 'text', 'kindeditor', '', '文章正文内容', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `ct_document_attribute` VALUES ('14', 'tags', '文章标签', 'varchar(128) NOT NULL', 'tags', '', '标签', '1', '', '3', '1383891233', '1384508496', '1');
INSERT INTO `ct_document_attribute` VALUES ('15', 'cover', '封面', 'int(11) unsigned NOT NULL ', 'picture', '0', '文档封面', '1', '', '3', '1383891233', '1384508496', '1');

-- -----------------------------
-- Table structure for `ct_document_extend_article`
-- -----------------------------
DROP TABLE IF EXISTS `ct_document_extend_article`;
CREATE TABLE `ct_document_extend_article` (
  `id` int(11) unsigned NOT NULL COMMENT '文档ID',
  `tags` varchar(128) NOT NULL DEFAULT '' COMMENT '标签',
  `abstract` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `content` text NOT NULL COMMENT '正文内容',
  `cover` int(11) NOT NULL DEFAULT '0' COMMENT '封面图片ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章类型扩展表';


-- -----------------------------
-- Table structure for `ct_document_type`
-- -----------------------------
DROP TABLE IF EXISTS `ct_document_type`;
CREATE TABLE `ct_document_type` (
  `id` tinyint(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(16) NOT NULL DEFAULT '' COMMENT '模型名称',
  `title` char(16) NOT NULL DEFAULT '' COMMENT '模型标题',
  `icon` varchar(32) NOT NULL DEFAULT '' COMMENT '缩略图',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '' COMMENT '表单字段分组',
  `system` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '系统类型',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `ct_document_type`
-- -----------------------------
INSERT INTO `ct_document_type` VALUES ('1', 'Link', '链接', 'icon-link', '', '', '1', '1426580628', '1426580628', '0', '1');
INSERT INTO `ct_document_type` VALUES ('2', 'Page', '单页', 'icon-file', '', '', '1', '1426580628', '1426580628', '0', '1');
INSERT INTO `ct_document_type` VALUES ('3', 'Article', '文章', 'icon-edit', '{\"1\":[\"1\",\"3\",\"12\",\"13\",\"14\",\"15\"],\"2\":[\"10\",\"8\"]}', '1:基础\n2:扩展', '0', '1426580628', '1426580628', '0', '1');

-- -----------------------------
-- Table structure for `ct_public_digg`
-- -----------------------------
DROP TABLE IF EXISTS `ct_public_digg`;
CREATE TABLE `ct_public_digg` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `table` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '数据表ID',
  `data_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据ID',
  `type` tinyint(3) NOT NULL DEFAULT '0' COMMENT 'Digg类型',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Digg表';


-- -----------------------------
-- Table structure for `ct_store_module`
-- -----------------------------
DROP TABLE IF EXISTS `ct_store_module`;
CREATE TABLE `ct_store_module` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '名称',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `description` varchar(128) NOT NULL DEFAULT '' COMMENT '描述',
  `developer` varchar(32) NOT NULL DEFAULT '' COMMENT '开发者',
  `version` varchar(8) NOT NULL DEFAULT '' COMMENT '版本',
  `admin_menu` text NOT NULL COMMENT '菜单节点',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ct_system_config`
-- -----------------------------
DROP TABLE IF EXISTS `ct_system_config`;
CREATE TABLE `ct_system_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '配置标题',
  `name` varchar(32) NOT NULL COMMENT '配置名称',
  `value` text NOT NULL COMMENT '配置值',
  `group` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `type` varchar(16) NOT NULL DEFAULT '' COMMENT '配置类型',
  `options` varchar(255) NOT NULL DEFAULT '' COMMENT '配置额外值',
  `tip` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `ct_system_config`
-- -----------------------------
INSERT INTO `ct_system_config` VALUES ('1', '站点开关', 'TOGGLE_WEB_SITE', '1', '1', 'select', '0:关闭,1:开启', '站点关闭后将不能访问', '1378898976', '1406992386', '1', '1');
INSERT INTO `ct_system_config` VALUES ('2', '网站标题', 'WEB_SITE_TITLE', 'CoreThink', '1', 'text', '', '网站标题前台显示标题', '1378898976', '1379235274', '2', '1');
INSERT INTO `ct_system_config` VALUES ('3', '网站口号', 'WEB_SITE_SLOGAN', '轻量级WEB产品开发框架', '1', 'text', '', '网站口号、宣传标语、一句话介绍', '1434081649', '1434081649', '2', '1');
INSERT INTO `ct_system_config` VALUES ('4', '网站LOGO', 'WEB_SITE_LOGO', '', '1', 'picture', '', '网站LOGO', '1407003397', '1407004692', '3', '1');
INSERT INTO `ct_system_config` VALUES ('5', '网站描述', 'WEB_SITE_DESCRIPTION', 'CoreThink是一套轻量级WEB产品开发框架，追求简单、高效、卓越。可轻松实现移动互联网时代支持多终端的轻量级WEB产品快速开发。系统功能采用模块化开发，内置丰富的模块，便于用户灵活扩展和二次开发。', '1', 'textarea', '', '网站搜索引擎描述', '1378898976', '1379235841', '4', '1');
INSERT INTO `ct_system_config` VALUES ('6', '网站关键字', 'WEB_SITE_KEYWORD', '南京科斯克网络科技、CoreThink', '1', 'textarea', '', '网站搜索引擎关键字', '1378898976', '1381390100', '5', '1');
INSERT INTO `ct_system_config` VALUES ('7', '版权信息', 'WEB_SITE_COPYRIGHT', '版权所有 © 2014-2015 科斯克网络科技', '1', 'text', '', '设置在网站底部显示的版权信息，如“版权所有 © 2014-2015 科斯克网络科技”', '1406991855', '1406992583', '6', '1');
INSERT INTO `ct_system_config` VALUES ('8', '网站备案号', 'WEB_SITE_ICP', '苏ICP备1502009-2号', '1', 'text', '', '设置在网站底部显示的备案号，如“苏ICP备1502009-2号\"', '1378900335', '1415983236', '7', '1');
INSERT INTO `ct_system_config` VALUES ('9', '站点统计', 'WEB_SITE_STATISTICS', '', '1', 'textarea', '', '支持百度、Google、cnzz等所有Javascript的统计代码', '1407824190', '1407824303', '8', '1');
INSERT INTO `ct_system_config` VALUES ('10', '前台主题', 'DEFAULT_THEME', 'default', '1', 'select', 'default:默认', '前台模版主题，不影响后台', '1425215616', '1425299454', '9', '1');
INSERT INTO `ct_system_config` VALUES ('11', '注册开关', 'TOGGLE_USER_REGISTER', '1', '2', 'select', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '2', '1');
INSERT INTO `ct_system_config` VALUES ('12', '注册时间间隔', 'LIMIT_TIME_BY_IP', '0', '2', 'num', '', '同一IP注册时间间隔秒数', '1379228036', '1379228036', '2', '1');
INSERT INTO `ct_system_config` VALUES ('13', '评论开关', 'TOGGLE_USER_COMMENT', '1', '2', 'select', '0:关闭评论,1:允许评论', '评论关闭后用户不能进行评论', '1418715779', '1418716106', '3', '1');
INSERT INTO `ct_system_config` VALUES ('14', '文件上传大小', 'UPLOAD_FILE_SIZE', '10', '2', 'num', '', '文件上传大小单位：MB', '1428681031', '1428681031', '4', '1');
INSERT INTO `ct_system_config` VALUES ('15', '图片上传大小', 'UPLOAD_IMAGE_SIZE', '2', '2', 'num', '', '图片上传大小单位：MB', '1428681071', '1428681071', '5', '1');
INSERT INTO `ct_system_config` VALUES ('16', '敏感字词', 'SENSITIVE_WORDS', '傻逼,垃圾', '2', 'textarea', '', '用户注册及内容显示敏感字词', '1420385145', '1420387079', '6', '1');
INSERT INTO `ct_system_config` VALUES ('17', '后台主题', 'ADMIN_THEME', 'default', '3', 'select', 'default:默认主题\r\nblueidea:蓝色理想\r\ngreen:绿色生活', '后台界面主题', '1436678171', '1436690570', '0', '1');
INSERT INTO `ct_system_config` VALUES ('18', '是否显示页面Trace', 'SHOW_PAGE_TRACE', '0', '3', 'select', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '1');
INSERT INTO `ct_system_config` VALUES ('19', '开发模式', 'DEVELOP_MODE', '1', '3', 'select', '1:开启\r\n0:关闭', '开发模式下会显示菜单管理、配置管理、数据字典等开发者工具', '1432393583', '1432393583', '2', '1');
INSERT INTO `ct_system_config` VALUES ('20', '配置分组', 'CONFIG_GROUP_LIST', '1:基本\r\n2:用户\r\n3:系统\r\n4:上传\r\n', '3', 'array', '', '配置分组', '1379228036', '1426930700', '3', '1');
INSERT INTO `ct_system_config` VALUES ('21', '分页数量', 'ADMIN_PAGE_ROWS', '10', '3', 'num', '', '分页时每页的记录数', '1434019462', '1434019481', '4', '1');
INSERT INTO `ct_system_config` VALUES ('22', '栏目分组', 'CATEGORY_GROUP_LIST', '1:默认\r\n3:导航\r\n', '3', 'array', '', '栏目分类分组', '1433602137', '1433602165', '5', '1');
INSERT INTO `ct_system_config` VALUES ('23', '文件上传驱动类型', 'UPLOAD_DRIVER', 'Local', '4', 'select', 'Local:Local-本地\r\nFtp:FTP空间\r\nSae:Sae-Storage\r\nBcs:Bcs云存储\r\nUpyun:又拍云\r\nQiniu:七牛云存储', '需要配置相应的UPLOAD_{driver}_CONFIG 配置方可使用，不然默认Local本地', '1393073505', '1393073505', '1', '1');
INSERT INTO `ct_system_config` VALUES ('24', 'FTP上传配置', 'UPLOAD_FTP_CONFIG', 'host:\r\nusername:\r\npassword:', '4', 'array', '', 'FTP上传配置', '1393073559', '1393073559', '2', '1');
INSERT INTO `ct_system_config` VALUES ('25', 'Sae上传配置', 'UPLOAD_SAE_CONFIG', 'domain:', '4', 'array', '', 'Sae上传配置', '1393073998', '1393073998', '3', '1');
INSERT INTO `ct_system_config` VALUES ('26', 'Bcs上传配置', 'UPLOAD_BCS_CONFIG', 'AccessKey:\r\nSecretKey:\r\nbucket:', '4', 'array', '', 'Bcs上传配置', '1393073559', '1393073559', '4', '1');
INSERT INTO `ct_system_config` VALUES ('27', '又拍云上传配置', 'UPLOAD_UPYUN_CONFIG', 'host:\r\nusername:\r\npassword:\r\nbucket:', '4', 'array', '', '又拍云上传配置', '1393073559', '1393073559', '5', '1');
INSERT INTO `ct_system_config` VALUES ('28', '七牛云存储上传配置', 'UPLOAD_QINIU_CONFIG', 'secrectKey:\r\naccessKey:\r\ndomain:\r\nbucket:', '4', 'array', '', '七牛云存储上传配置', '1393074989', '1416637334', '6', '1');

-- -----------------------------
-- Table structure for `ct_system_menu`
-- -----------------------------
DROP TABLE IF EXISTS `ct_system_menu`;
CREATE TABLE `ct_system_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级菜单ID',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `url` varchar(128) NOT NULL DEFAULT '' COMMENT '链接地址',
  `icon` varchar(64) NOT NULL COMMENT '图标',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8 COMMENT='后台菜单表';

-- -----------------------------
-- Records of `ct_system_menu`
-- -----------------------------
INSERT INTO `ct_system_menu` VALUES ('1', '0', '首页', 'Admin/Index/index', 'glyphicon glyphicon-home', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('2', '0', '系统', 'Admin/SystemConfig/group', 'glyphicon glyphicon-cog', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('3', '0', '内容', 'Admin/Category/index', 'glyphicon glyphicon-tasks', '1430290092', '1430291772', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('4', '0', '用户', 'Admin/User/index', 'glyphicon glyphicon-user', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('5', '0', '其它', '', 'glyphicon glyphicon-cloud', '1426580628', '1426580628', '3', '0');
INSERT INTO `ct_system_menu` VALUES ('6', '1', '系统操作', '', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('7', '2', '系统功能', '', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('8', '2', '数据备份', '', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('9', '3', '文档管理', '', '', '1430290276', '1430291485', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('10', '3', '文件管理', '', '', '1430290276', '1430291485', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('11', '4', '用户管理', '', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('12', '6', '清空缓存', 'Admin/Index/rmdirr', '', '1427475588', '1427475588', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('13', '7', '系统设置', 'Admin/SystemConfig/group', '', '1426580628', '1430291269', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('14', '13', '修改', 'Admin/SystemConfig/groupSave', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('15', '7', '文档类型', 'Admin/DocumentType/index', '', '1426580628', '1430291065', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('16', '15', '添加', 'Admin/DocumentType/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('17', '15', '编辑', 'Admin/DocumentType/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('18', '15', '设置状态', 'Admin/DocumentType/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('19', '15', '字段管理', 'Admin/DocumentAttribute/index', '', '1426580628', '1430291065', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('20', '19', '添加', 'Admin/DocumentAttribute/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('21', '19', '编辑', 'Admin/DocumentAttribute/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('22', '19', '设置状态', 'Admin/DocumentAttribute/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('23', '7', '菜单管理', 'Admin/SystemMenu/index', '', '1426580628', '1430291065', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('24', '23', '添加', 'Admin/SystemMenu/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('25', '23', '编辑', 'Admin/SystemMenu/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('26', '23', '设置状态', 'Admin/SystemMenu/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('27', '7', '配置管理', 'Admin/SystemConfig/index', '', '1426580628', '1430291167', '4', '1');
INSERT INTO `ct_system_menu` VALUES ('28', '27', '添加', 'Admin/SystemConfig/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('29', '27', '编辑', 'Admin/SystemConfig/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('30', '27', '设置状态', 'Admin/SystemConfig/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('31', '7', '数据字典', 'Admin/Datebase/index', '', '1429851071', '1430291185', '5', '1');
INSERT INTO `ct_system_menu` VALUES ('32', '7', '插件列表', 'Admin/Addon/index', '', '1427475588', '1427475588', '6', '1');
INSERT INTO `ct_system_menu` VALUES ('33', '32', '安装', 'Admin/Addon/install', '', '1427475588', '1427475588', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('34', '32', '卸载', 'Admin/Addon/uninstall', '', '1427475588', '1427475588', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('35', '32', '执行', 'Admin/Addon/execute', '', '1427475588', '1427475588', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('36', '32', '插件设置', 'Admin/Addon/config', '', '1427475588', '1427475588', '4', '1');
INSERT INTO `ct_system_menu` VALUES ('37', '32', '数据列表', 'Admin/Addon/adminList', '', '1427475588', '1427475588', '5', '1');
INSERT INTO `ct_system_menu` VALUES ('38', '8', '数据备份', 'Admin/Datebase/export', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('39', '38', '备份', 'Admin/Datebase/do_export', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('40', '38', '优化表', 'Admin/Datebase/optimize', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('41', '38', '修复表', 'Admin/Datebase/repair', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('42', '8', '数据还原', 'Admin/Datebase/import', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('43', '42', '还原备份', 'Admin/Datebase/do_import', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('44', '42', '删除备份', 'Admin/Datebase/del', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('45', '9', '栏目分类', 'Admin/Category/index', '', '1426580628', '1430290312', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('46', '45', '添加', 'Admin/Category/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('47', '45', '编辑', 'Admin/Category/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('48', '45', '设置状态', 'Admin/Category/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('50', '45', '文档列表', 'Admin/Document/index', '', '1427475588', '1427475588', '4', '1');
INSERT INTO `ct_system_menu` VALUES ('51', '50', '添加', 'Admin/Document/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('52', '50', '编辑', 'Admin/Document/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('53', '50', '设置状态', 'Admin/Document/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('54', '9', '标签列表', 'Admin/Tag/index', '', '1426580628', '1430290718', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('55', '54', '添加', 'Admin/Tag/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('56', '54', '编辑', 'Admin/Tag/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('57', '54', '设置状态', 'Admin/Tag/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('58', '9', '万能评论', 'Admin/UserComment/index', '', '1426580628', '1426580628', '4', '1');
INSERT INTO `ct_system_menu` VALUES ('59', '58', '添加', 'Admin/UserComment/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('60', '58', '编辑', 'Admin/UserComment/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('61', '58', '设置状态', 'Admin/UserComment/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('62', '9', '回收站', 'Admin/Document/recycle', '', '1427475588', '1430290597', '5', '1');
INSERT INTO `ct_system_menu` VALUES ('63', '10', '上传管理', 'Admin/Upload/index', '', '1427475588', '1427475588', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('64', '63', '上传文件', 'Admin/Upload/upload', '', '1427475588', '1427475588', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('65', '63', '下载图片', 'Admin/Upload/downremoteimg', '', '1427475588', '1427475588', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('66', '63', '文件浏览', 'Admin/Upload/fileManager', '', '1427475588', '1427475588', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('67', '11', '用户列表', 'Admin/User/index', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('68', '67', '添加', 'Admin/User/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('69', '67', '编辑', 'Admin/User/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('70', '67', '设置状态', 'Admin/User/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('71', '11', '部门管理', 'Admin/UserGroup/index', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('72', '71', '添加', 'Admin/UserGroup/add', '', '1426580628', '1426580628', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('73', '71', '编辑', 'Admin/UserGroup/edit', '', '1426580628', '1426580628', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('74', '71', '设置状态', 'Admin/UserGroup/setStatus', '', '1426580628', '1426580628', '3', '1');
INSERT INTO `ct_system_menu` VALUES ('75', '32', '新增数据', 'Admin/Addon/adminAdd', '', '1426580628', '1426580628', '6', '1');
INSERT INTO `ct_system_menu` VALUES ('76', '32', '编辑数据', 'Admin/Addon/adminEdit', '', '1426580628', '1426580628', '7', '1');
INSERT INTO `ct_system_menu` VALUES ('77', '32', '设置状态', 'Admin/Addon/setStatus', '', '1426580628', '1426580628', '8', '1');
INSERT INTO `ct_system_menu` VALUES ('78', '2', '应用商店', '', '', '1437185077', '1437185164', '2', '1');
INSERT INTO `ct_system_menu` VALUES ('79', '78', '功能模块', 'Admin/StoreModule/index', '', '1437185242', '1437185242', '1', '1');
INSERT INTO `ct_system_menu` VALUES ('80', '78', '前台主题', 'Admin/StoreTheme/index', '', '1437185290', '1437185290', '2', '0');
INSERT INTO `ct_system_menu` VALUES ('81', '78', '全局插件', 'Admin/StoreAddon/index', '', '1437185290', '1437185290', '3', '0');

-- -----------------------------
-- Table structure for `ct_tag`
-- -----------------------------
DROP TABLE IF EXISTS `ct_tag`;
CREATE TABLE `ct_tag` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(32) NOT NULL COMMENT '标签',
  `count` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数量',
  `group` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '分组',
  `cover` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '图标',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='标签表';


-- -----------------------------
-- Table structure for `ct_upload`
-- -----------------------------
DROP TABLE IF EXISTS `ct_upload`;
CREATE TABLE `ct_upload` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '上传ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '文件名',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '文件路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文件链接',
  `ext` char(4) NOT NULL DEFAULT '' COMMENT '文件类型',
  `size` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件sha1编码',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `utime` int(11) NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件上传表';


-- -----------------------------
-- Table structure for `ct_user`
-- -----------------------------
DROP TABLE IF EXISTS `ct_user`;
CREATE TABLE `ct_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `usertype` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '用户类型',
  `username` varchar(32) NOT NULL DEFAULT '' COMMENT '用户名或昵称',
  `email` varchar(32) DEFAULT NULL COMMENT '用户邮箱',
  `mobile` char(11) DEFAULT NULL COMMENT '手机号',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '用户密码',
  `group` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '部门/用户组ID',
  `vip` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT ' VIP等级',
  `avatar` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户头像',
  `score` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户积分',
  `money` decimal(11,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '账户余额',
  `sex` enum('-1','0','1') NOT NULL DEFAULT '0' COMMENT '用户性别',
  `age` int(4) NOT NULL DEFAULT '0' COMMENT '年龄',
  `birthday` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '生日',
  `summary` varchar(127) NOT NULL DEFAULT '' COMMENT '心情',
  `realname` varchar(15) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `idcard_no` varchar(18) NOT NULL DEFAULT '' COMMENT '身份证号码',
  `extend` varchar(1024) NOT NULL DEFAULT '' COMMENT '用户信息扩展',
  `login` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `last_login_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最近登陆时间',
  `last_login_ip` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最近登陆IP',
  `reg_ip` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '注册方式',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mobile` (`mobile`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户会员信息表';

-- -----------------------------
-- Records of `ct_user`
-- -----------------------------
INSERT INTO `ct_user` VALUES ('1', '0', 'admin', '316235872@qq.com', '18521353332', '79cc780bd21b161230268824080b8476', '1', '0', '0', '0', '0.00', '0', '0', '0', '', '', '', '', '2', '1438047664', '2130706433', '0', '0', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `ct_user_comment`
-- -----------------------------
DROP TABLE IF EXISTS `ct_user_comment`;
CREATE TABLE `ct_user_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论父ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `table` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '数据表ID',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '分组',
  `data_id` int(11) unsigned NOT NULL COMMENT '数据ID',
  `content` text NOT NULL COMMENT '评论内容',
  `pictures` varchar(15) NOT NULL DEFAULT '' COMMENT '图片列表',
  `rate` tinyint(3) NOT NULL DEFAULT '0' COMMENT '评价/评分',
  `good` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '赞数',
  `bad` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '踩数',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `ip` varchar(15) NOT NULL COMMENT '来源IP',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='评论表';


-- -----------------------------
-- Table structure for `ct_user_group`
-- -----------------------------
DROP TABLE IF EXISTS `ct_user_group`;
CREATE TABLE `ct_user_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上级部门ID',
  `title` varchar(32) NOT NULL DEFAULT '' COMMENT '部门名称',
  `icon` varchar(32) NOT NULL COMMENT '图标',
  `auth` varchar(1024) NOT NULL DEFAULT '' COMMENT '权限',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='部门信息表';

-- -----------------------------
-- Records of `ct_user_group`
-- -----------------------------
INSERT INTO `ct_user_group` VALUES ('1', '0', '管理员', '', '', '1426881003', '1427552428', '0', '1');

-- -----------------------------
-- Table structure for `ct_user_message`
-- -----------------------------
DROP TABLE IF EXISTS `ct_user_message`;
CREATE TABLE `ct_user_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `pid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '消息父ID',
  `title` varchar(1024) NOT NULL DEFAULT '' COMMENT '消息内容',
  `type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0系统消息,1评论消息,2私信消息',
  `to_uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '接收用户ID',
  `from_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '私信消息发信用户ID',
  `is_read` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '是否已读',
  `ctime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送时间',
  `utime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户消息表';

